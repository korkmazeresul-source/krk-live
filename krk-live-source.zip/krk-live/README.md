# KRK Live

TikTok LIVE yayınları için kamera önizlemesi, hediye hedefi ve gerçek zamanlı etkinlik paneli.

## Çalıştırma

Node.js 20+ ile `npm install` ve `npm start`.

Railway ortam değişkeni: `TIKTOK_USERNAME=krkmedya` (isteğe bağlı; varsayılan krkmedya).

## Not

TikTok LIVE bağlantısı resmî olmayan bir kütüphane kullanır; yayının aktif olması gerekir ve bağlantı garanti değildir. Hediyelerin TL karşılığı hesaplanmaz. İlk sürümde kalıcı veri tabanı, yönetici kimlik doğrulaması ve takım savaşı puanlama kuralları yoktur.
